# LibraryApp

Ứng dụng quản lý sách và theo dõi mượn/trả, xây dựng bằng React Native CLI.

## Chạy ứng dụng

Cài dependencies bằng `npm install`, sau đó:

```sh
npm start
npm run android
```

Để chạy trên iOS, cài CocoaPods bằng `bundle exec pod install` trong thư mục `ios`, sau đó chạy `npm run ios`.

## Chức năng

- Danh sách sách, tổng số đầu sách và số cuốn đang được mượn.
- Tìm kiếm theo tên/tác giả và lọc đồng thời theo thể loại.
- Thêm, sửa và xoá sách (xoá cần xác nhận; sách đang được mượn không thể xoá).
- Chi tiết sách và cập nhật số lượng mượn/trả.
- Dữ liệu được lưu cục bộ bằng AsyncStorage; lần chạy đầu khởi tạo năm sách mẫu.

Màn hình nằm trong `src/screens`, các thành phần dùng chung trong `src/components`, kiểu dữ liệu trong `src/types` và bảng màu trong `src/theme/colors.ts`.
